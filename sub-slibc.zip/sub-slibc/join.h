#ifndef JOIN_H_INCLUDED
#define JOIN_H_INCLUDED

#include_next <errno.h>
//#include <unistd.h>
//#include <fcntl.h>

#define STRUNCATE
#if defined(_ERRNO_H) && !defined(SLIBC_ERRNO_H)
#define  SLIBC_ERRNO_H

#ifndef _CRT_SECURE_NO_DEPRECATE
#define _CRT_SECURE_NO_DEPRECATE 1


#if (!defined(__STDC_WANT_LIB_EXT1__) || (__STDC_WANT_LIB_EXT1__ != 0))


typedef int errno_t;
errno_t gets_s(char *str, size_t size);
strnlen(const char *str, size_t maxlen) ;

errno_t strcpy_s(char *dest, size_t n, const char *src);
errno_t strncpy_s(char *dest, size_t n, const char *src, size_t count);

errno_t strcat_s(char *dest, size_t n, const char *src);
errno_t strncat_s(char *dest, size_t n, const char *src, size_t count);

errno_t strlwr_s(char *s, size_t n);
errno_t strupr_s(char *s, size_t n);

char *strnstr_s(const char *s1, size_t n1, const char *s2, size_t n2);
char *strchr_s(const char *s, size_t n, int c);



#endif
#endif
#endif

#endif // JOIN_H_INCLUDED
