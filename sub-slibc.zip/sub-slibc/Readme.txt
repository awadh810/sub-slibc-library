#string_utils    
 
هي جزء من مكتبة slibc وتحتوي على بعض من دوال معالجة النصوص  مثل :   ( strchr_s , strupr_s , strcat_s , strncpy_s , strcpy_s , strncat_s , gets_s ,strnlen )

# طريقة الاستخدام:
1: انشئ مشروع بلغة السي 
2:  فك الضغط عن مجلد sub-slibc 
3: انسخ الملفين join.h و string_utils.c  الى مجلد مشروعك في نفس المكان الذي فيه ملف main.c
4: ادخل على ملف main.c في محرر الاكواد الخاص بك ( CodeBlocks )  واعمل تضمين للملفين السابقين join.h   و string_utils.c   
5: تستطيع ان تستدعي اي دالة من الدوال الموجودة في ملف string_utils.c

#طريقة عمل تضمين (include) للملفات: 
>> إذا قمت بوضع الملفين السابقين في نفس مجلد المشروع يكون المسار نسبي بالشكل التالي:
"include "join.h#
"include "string_utils.c#

>> يفضل وضع الملفات في نفس المسار  للمشروع لكن يمكن ان تكون في مكان اخر   فتستخدم المسار الكامل للملفات بالشكل التالي:
"include "C:\Awadh\Files\string_utils.c#
"include "C:\Awadh\Files\join.h#

#لمعرفة اكثر عن طريقة استخدام  الدوال وتضمين الملفات افتح المشروع string_manipulation الموجود في مجلد   sub-slibc 

