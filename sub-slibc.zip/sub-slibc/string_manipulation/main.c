#include <stdio.h>
#include <stdlib.h>
//#include  "join.h"
#include  "string_utils.c"

int main()
{

// Below tow examples on Every Functions to Explain How to use These Functions >> the first Example will not execute  because it has an error , the second one is correct will give you a result
// Use Every Example Alone To avoid collisions in array names defined more than once.

// ****************************************** gets_s FUN. Example  : ******************************************
    char arra[10];
    printf("%s" ,"Enter The Input: ");
    if ( gets_s(arra , sizeof(arra)) != 0 )
    {
        printf("%s" ,"Failed Reading\n");
        //printf("%s" , arra);
    }
    else
    {
        printf("%s" , "Successfully Reading\n");
        printf("%s \n" , arra);
    }




// ****************************************** strcpy_s FUN. Example 1 : ******************************************
    /*
    char arr[5] = "ali";
    char arr2[] = "ahmed";

    if (strcpy_s(arr , sizeof(arr) , arr2) == 0)
    {
         printf("Successful Copies\n");
         printf(arr);
    }
    */
// ------------------------------------------------ Example 2 -------------------------------------------

    /*char arr[] = "ali";
    char arr2[10] = "ahmed";

    if (strcpy_s(arr2 , sizeof(arr2) , arr) == 0)
    {
         printf("Successful Copies\n");
         printf(arr);
    }*/




// ****************************************** strncpy_s FUN. Example 1 :  ******************************************
    /*
    char arr[4] = "ali";
    char arr2[] = "ahmed";

    if (strncpy_s(arr , sizeof(arr) , arr2 , 4) == 0)
    {
         printf("Successful Copies\n");
         printf(arr);
    }
    */
// ------------------------------------------------ Example 2 -------------------------------------------
    /*
    char arr[6] = "ali";
    char arr2[] = "ahmed";

    if (strncpy_s(arr , sizeof(arr) , arr2 , 5) == 0)
    {
         printf("Successful Copies\n");
         printf(arr);
    }
    */



// **********************************************  strcat_s FUN. Example 1 :    ******************************************
    /*
    char arr[] = "ali";
    char arr2[] = "ahmed";

    if (strcat_s(arr , sizeof(arr) , arr2 ) == 0)
    {
         printf("Successful Copies\n");
         printf(arr);
    }
    */
// ------------------------------------------------ Example 2 -------------------------------------------

    /*char arr[] = "ali";
    char arr2[10] = "ahmed";

    if (strcat_s(arr2 , sizeof(arr2) , arr ) == 0)
    {
         printf("Successful Copies\n");
         printf(arr2);
    }
    */



// **********************************************  strncat_s FUN. Example 1 :    ******************************************
    /*
    char arr[] = "ali";
    char arr2[] = "ahmed";
    if (strncat_s(arr , sizeof(arr) , arr2 , 2) == 0)
    {
         printf("Successful Copies\n");
         printf(arr);
    }
    */
// ------------------------------------------------ Example 2 -------------------------------------------
    /*
    char arr[7] = "ali";
    char arr2[] = "ahmed";
    if (strncat_s(arr , sizeof(arr) , arr2 , 2) == 0)
    {
         printf("Successful Copies\n");
         printf(arr);
    }
    */


    return 0;
}
