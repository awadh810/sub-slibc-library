#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include  "join.h"

typedef int errno_t;



errno_t gets_s(char *str, size_t size) {
    if (size == 0) {
        return ERANGE;
    }

    char *p = fgets(str, size, stdin);
    if (p == NULL) {
        return EOF;
    }

    // Find the newline character
    char *nl = strchr(str, '\n');
    if (nl != NULL) {
        *nl = '\0';
    }

    return 0;
}


size_t strnlen(const char *str, size_t maxlen) {
  size_t len = 0;
  while (len < maxlen && str[len] != '\0') {
    len++;
  }
  return len;
}


errno_t strcpy_s(char *dest, size_t n, const char *src) {
  if (n == 0) {
    return ERANGE;
  }

  size_t len = strlen(src);
  if (len >= n) {
    return ERANGE;
  }

  strcpy(dest, src);
  dest[len] = '\0';

  return 0;
}


errno_t strncpy_s(char *dest, size_t n, const char *src, size_t count) {
  if (n == 0) {
    return ERANGE;
  }

  size_t len = strnlen(src, count);
  if (len >= n) {
    return ERANGE;
  }

  strncpy(dest, src, count);
  dest[len] = '\0';

  return 0;
}



errno_t strcat_s(char *dest, size_t n, const char *src) {
  size_t dest_len = strlen(dest);

  // Check for buffer overflow.
  if (dest_len + strlen(src) + 1 > n) {
    return STRUNCATE;
  }

  // Append the source string to the destination string.
  strcpy(dest + dest_len, src);

  dest[dest_len + strlen(src)] = '\0';

  return 0;
}


errno_t strncat_s(char *dest, size_t n, const char *src, size_t count) {
  size_t dest_len = strlen(dest);

  // Check for buffer overflow.
  if (dest_len + count + 1 > n) {
    return STRUNCATE;
  }

  // Append the first `count` characters of the source string to the destination string.
  strncpy(dest + dest_len, src, count);

  dest[dest_len + count] = '\0';

  return 0;
}



errno_t strlwr_s(char *s, size_t n) {
  if (s == NULL || n == 0) {
    return EINVAL;
  }

  size_t i ;
  for (i = 0; i < n - 1; ++i) {
    unsigned char c = s[i];
    if (c >= 'A' && c <= 'Z') {
      s[i] = c + 'a' - 'A';
    }
  }

  s[n - 1] = '\0';
  return 0;
}


errno_t strupr_s(char *s, size_t n) {
  if (s == NULL || n == 0) {
    return EINVAL;
  }

  size_t i ;
  for ( i = 0; i < n - 1; ++i) {
    unsigned char c = s[i];
    if (c >= 'a' && c <= 'z') {
      s[i] = c - 'a' + 'A';
    }
  }

  s[n - 1] = '\0';
  return 0;
}


char *strnstr_s(const char *s1, size_t n1, const char *s2, size_t n2) {
  if (s1 == NULL || s2 == NULL || n1 == 0 || n2 == 0) {
    return NULL;
  }

  if (n2 > n1) {
    return NULL;
  }

   size_t i ;
  for ( i = 0; i < n1 - n2 + 1; ++i) {
    if (memcmp(s1 + i, s2, n2) == 0) {
      return (char *)s1 + i;
    }
  }

  return NULL;
}



char *strchr_s(const char *s, size_t n, int c) {
  if (s == NULL || n == 0) {
    return NULL;
  }

  size_t i ;
  for (i = 0; i < n; ++i) {
    if (s[i] == c) {
      return (char *)s + i;
    }
  }

  return NULL;
}

/* 
 * Prepared By : Awadh Bin Wahlan
*/
